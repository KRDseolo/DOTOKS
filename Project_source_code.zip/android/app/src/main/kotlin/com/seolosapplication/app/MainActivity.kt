package com.seolosapplication.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
