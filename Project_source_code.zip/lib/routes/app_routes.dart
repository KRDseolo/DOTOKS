import 'package:flutter/material.dart';
import '../core/app_export.dart';
import '../presentation/app_navigation_screen/app_navigation_screen.dart';
import '../presentation/container_screen/container_screen.dart';
import '../presentation/frame_2794_screen/frame_2794_screen.dart';
import '../presentation/k0_screen/k0_screen.dart';
import '../presentation/k10_screen/k10_screen.dart';
import '../presentation/k11_screen/k11_screen.dart';
import '../presentation/k12_screen/k12_screen.dart';
import '../presentation/k13_screen/k13_screen.dart';
import '../presentation/k14_screen/k14_screen.dart';
import '../presentation/k18_screen/k18_screen.dart';
import '../presentation/k19_screen/k19_screen.dart';
import '../presentation/k1_screen/k1_screen.dart';
import '../presentation/k20_screen/k20_screen.dart';
import '../presentation/k21_screen/k21_screen.dart';
import '../presentation/k2_screen/k2_screen.dart';
import '../presentation/k3_screen/k3_screen.dart';
import '../presentation/k4_screen/k4_screen.dart';
import '../presentation/k5_screen/k5_screen.dart';
import '../presentation/k6_screen/k6_screen.dart';
import '../presentation/k7_screen/k7_screen.dart';
import '../presentation/one_screen/one_screen.dart';
import '../presentation/three_screen/three_screen.dart';
import '../presentation/two_screen/two_screen.dart';
import '../presentation/wait_one_screen/wait_one_screen.dart';
import '../presentation/wait_screen/wait_screen.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class AppRoutes {
  static const String k0Screen = '/k0_screen';

  static const String k1Screen = '/k1_screen';

  static const String k2Screen = '/k2_screen';

  static const String k3Screen = '/k3_screen';

  static const String k4Screen = '/k4_screen';

  static const String k5Screen = '/k5_screen';

  static const String k6Screen = '/k6_screen';

  static const String k7Screen = '/k7_screen';

  static const String waitScreen = '/wait_screen';

  static const String waitOneScreen = '/wait_one_screen';

  static const String k10Screen = '/k10_screen';

  static const String k11Screen = '/k11_screen';

  static const String k12Screen = '/k12_screen';

  static const String k13Screen = '/k13_screen';

  static const String k14Screen = '/k14_screen';

  static const String k15Page = '/k15_page';

  static const String containerScreen = '/container_screen';

  static const String frame2794Screen = '/frame_2794_screen';

  static const String k18Screen = '/k18_screen';

  static const String k19Screen = '/k19_screen';

  static const String k20Screen = '/k20_screen';

  static const String k21Screen = '/k21_screen';

  static const String oneScreen = '/one_screen';

  static const String twoScreen = '/two_screen';

  static const String threeScreen = '/three_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static const String initialRoute = '/initialRoute';

  static Map<String, WidgetBuilder> routes = {
    k0Screen: (context) => K0Screen(),
    k1Screen: (context) => K1Screen(),
    k2Screen: (context) => K2Screen(),
    k3Screen: (context) => K3Screen(),
    k4Screen: (context) => K4Screen(),
    k5Screen: (context) => K5Screen(),
    k6Screen: (context) => K6Screen(),
    k7Screen: (context) => K7Screen(),
    waitScreen: (context) => WaitScreen(),
    waitOneScreen: (context) => WaitOneScreen(),
    k10Screen: (context) => K10Screen(),
    k11Screen: (context) => K11Screen(),
    k12Screen: (context) => K12Screen(),
    k13Screen: (context) => K13Screen(),
    k14Screen: (context) => K14Screen(),
    containerScreen: (context) => ContainerScreen(),
    frame2794Screen: (context) => Frame2794Screen(),
    k18Screen: (context) => K18Screen(),
    k19Screen: (context) => K19Screen(),
    k20Screen: (context) => K20Screen(),
    k21Screen: (context) => K21Screen(),
    oneScreen: (context) => OneScreen(),
    twoScreen: (context) => TwoScreen(),
    threeScreen: (context) => ThreeScreen(),
    appNavigationScreen: (context) => AppNavigationScreen(),
    initialRoute: (context) => K0Screen()
  };
}
