import 'package:flutter/material.dart';
import '../../core/app_export.dart';

class AppNavigationScreen extends StatelessWidget {
  const AppNavigationScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          width: 375.h,
          child: Column(
            children: [
              _buildAppNavigation(context),
              Expanded(
                child: SingleChildScrollView(
                  child: Container(
                    decoration: AppDecoration.fillWhiteA,
                    child: Column(
                      children: [
                        _buildScreenTitle(
                          context,
                          screenTitle: "스플래쉬 화면",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k0Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "로그인",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k1Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "설문 시작",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k2Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "설문 1페이지",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k3Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "설문 2페이지",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k4Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "설문 3페이지",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k5Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "설문 4페이지",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k6Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "설문 5페이지",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k7Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "wait",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.waitScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "wait One",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.waitOneScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "결과",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k10Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "정보",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k11Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "둘다 펼치기",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k12Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "앱 사용량 펼치기",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k13Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "챌린지 펼치기",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k14Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "메인 메뉴 - Container",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.containerScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Frame 2794",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.frame2794Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "커뮤니티",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k18Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "알림",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k19Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "설정",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k20Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "뭉근이 키우기",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k21Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "뭉근이 키우기 One",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.oneScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "뭉근이 키우기 Two",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.twoScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "뭉근이 키우기 Three",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.threeScreen),
                        )
                      ],
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildAppNavigation(BuildContext context) {
    return Container(
      decoration: AppDecoration.fillWhiteA,
      child: Column(
        children: [
          SizedBox(height: 10.v),
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.h),
              child: Text(
                "App Navigation",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: appTheme.black900,
                  fontSize: 20.fSize,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          ),
          SizedBox(height: 10.v),
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: EdgeInsets.only(left: 20.h),
              child: Text(
                "Check your app's UI from the below demo screens of your app.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: appTheme.blueGray400,
                  fontSize: 16.fSize,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          ),
          SizedBox(height: 5.v),
          Divider(
            height: 1.v,
            thickness: 1.v,
            color: appTheme.black900,
          )
        ],
      ),
    );
  }

  /// Common widget
  Widget _buildScreenTitle(
    BuildContext context, {
    required String screenTitle,
    Function? onTapScreenTitle,
  }) {
    return GestureDetector(
      onTap: () {
        onTapScreenTitle?.call();
      },
      child: Container(
        decoration: AppDecoration.fillWhiteA,
        child: Column(
          children: [
            SizedBox(height: 10.v),
            Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.h),
                child: Text(
                  screenTitle,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: appTheme.black900,
                    fontSize: 20.fSize,
                    fontFamily: 'Roboto',
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
            ),
            SizedBox(height: 10.v),
            SizedBox(height: 5.v),
            Divider(
              height: 1.v,
              thickness: 1.v,
              color: appTheme.blueGray400,
            )
          ],
        ),
      ),
    );
  }

  /// Common click event
  void onTapScreenTitle(
    BuildContext context,
    String routeName,
  ) {
    Navigator.pushNamed(context, routeName);
  }
}
