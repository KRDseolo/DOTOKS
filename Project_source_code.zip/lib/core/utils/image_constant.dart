// ignore_for_file: must_be_immutable
class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

// 스플래쉬 화면 images
  static String imgDotox = '$imagePath/img_dotox.png';

// 로그인 images
  static String imgInvisible1 = '$imagePath/img_invisible_1.svg';

  static String imgFacebook = '$imagePath/img_facebook.svg';

  static String imgPlay = '$imagePath/img_play.svg';

  static String imgGoogle = '$imagePath/img_google.svg';

// 설문 5페이지 images
  static String imgFrame2790 = '$imagePath/img_frame_2790.svg';

// 정보 images
  static String imgInbox = '$imagePath/img_inbox.svg';

// 앱 사용량 펼치기 images
  static String imgEllipse11 = '$imagePath/img_ellipse_11.png';

// 챌린지 펼치기 images
  static String imgArrowForwardI1 = '$imagePath/img_arrow_forward_i_1.png';

// Frame 2794 images
  static String imgPath = '$imagePath/img_path.svg';

  static String imgChart = '$imagePath/img_chart.png';

  static String imgEllipse29 = '$imagePath/img_ellipse_29.png';

  static String imgEllipse30 = '$imagePath/img_ellipse_30.png';

  static String imgEllipse31 = '$imagePath/img_ellipse_31.png';

// 커뮤니티 images
  static String imgEllipse37 = '$imagePath/img_ellipse_37.png';

// 설정 images
  static String img40x40 = '$imagePath/img__40x40.png';

  static String img1 = '$imagePath/img__1.png';

  static String img41x41 = '$imagePath/img__41x41.png';

  static String img38x35 = '$imagePath/img__38x35.png';

  static String img35x35 = '$imagePath/img__35x35.png';

  static String img37x37 = '$imagePath/img__37x37.png';

// Common images
  static String imgThumbsup = '$imagePath/img_thumbsup.svg';

  static String imgDotox1 = '$imagePath/img_dotox_1.png';

  static String imgCarrotIllustrationFreePng =
      '$imagePath/img_carrot_illustration_free_png.png';

  static String imgEllipse13 = '$imagePath/img_ellipse_13.png';

  static String imgArrowForwardI = '$imagePath/img_arrow_forward_i.png';

  static String img = '$imagePath/img_.svg';

  static String imgOnlydotox3 = '$imagePath/img_onlydotox_3.png';

  static String img11 = '$imagePath/img_1_1.png';

  static String imgPerson24dpFil = '$imagePath/img_person_24dp_fil.png';

  static String imgBarChart24dp = '$imagePath/img_bar_chart_24dp.png';

  static String imgSettings24dpF = '$imagePath/img_settings_24dp_f.png';

  static String imgNotifications2 = '$imagePath/img_notifications_2.png';

  static String imgArrowForwardI16x16 =
      '$imagePath/img_arrow_forward_i_16x16.png';

  static String img12 = '$imagePath/img_1_2.png';

  static String img50x50 = '$imagePath/img__50x50.png';

  static String img49x39 = '$imagePath/img__49x39.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
